#!/bin/bash
fatal_error()
{
        echo "[ $(date +"%T.%3N") ] $1";
        # Set fatal logo
        if [ -e "/fatal.raw" ]; then
                cat /fatal.raw > /dev/fb0;
                echo 0 > /sys/class/graphics/fb0/blank;
        fi
        # Check for volume up
        timeout 10s cat /dev/input/event4 | read -n 1
        if [ $? -eq 0 ]; then
                # Signal a flash that we entered bash
                echo 4 > /sys/class/graphics/fb0/blank;
                cat /dev/null > /dev/fb0;
                echo 0 > /sys/class/graphics/fb0/blank;
                exec /bin/bash;
        else reboot; fi
}
if [[ $(mount | grep /sysroot | head -n 1 |awk '{print $1}') == "" ]]; then
	fatal_error
fi

#Remount root filesystem as read/write
mount -o remount,rw /sysroot

if [ ! -f /sysroot/etc/.resized ]; then
	resize2fs $(mount | grep /sysroot | head -n 1 |awk '{print $1}');
	if [ $? -eq 0 ]; then echo "" > /sysroot/etc/.resized; echo "Root fs resized"; fi
fi

mount /dev/mmcblk0p1 /sysroot/boot;

if [ $? -ne 0 ]; then
	mount /dev/mmcblk1p1 /sysroot/boot;
	if [ $? -eq 0 ]; then boot_dev_found="true"; fi
else
	boot_dev_found="true";
fi;

if [[ ${boot_dev_found} == "true" ]]; then
	SWR_DIR=$(sed -e 's/.*swr_dir=//' -e 's/\s.*$//' /proc/cmdline);
	if [[ -n ${SWR_DIR} ]]; then
		if [[ -f /sysroot/boot/switchroot/${SWR_DIR}/modules.tar.gz ]]; then
			echo "Deleting old modules";
			rm -r /sysroot/lib/modules/*;
			echo "Extracting new modules";
			tar -hxpf /sysroot/boot/switchroot/${SWR_DIR}/modules.tar.gz -C /sysroot/lib/;
			if [ $? -eq 0 ]; then rm /sysroot/boot/switchroot/${SWR_DIR}/modules.tar.gz; echo "Extract success"; fi
		fi

		if [[ -f /sysroot/boot/switchroot/${SWR_DIR}/update.tar.gz ]]; then
			echo "Extracting update.tar.gz";
			tar -hxpf /sysroot/boot/switchroot/${SWR_DIR}/update.tar.gz -C /sysroot/;
			if [ $? -eq 0 ]; then rm /sysroot/boot/switchroot/${SWR_DIR}/update.tar.gz; echo "Extract success"; fi
		fi
	fi
fi

echo "[ $(date +"%T.%3N") ] Set Up Joycon stuff"
# Create Fallback Bluetooth MAC
BT_MAC_ADDR=$(sed -e "s/^"0x"//" /sys/block/mmcblk0/device/serial)
BT_MAC_ADDR=${BT_MAC_ADDR%??}
BT_MAC_ADDR="98B6E9${BT_MAC_ADDR}"
# Create Wifi MAC Should never change, once set....
NEW_WIFI_MAC=${BT_MAC_ADDR%??}
NEW_WIFI_MAC=${NEW_WIFI_MAC}$(sed -e "s/^"0x"//" /sys/block/mmcblk0/device/serial | grep -o '.\{2\}$')
NEW_WIFI_MAC=$(echo ${NEW_WIFI_MAC} | tr '[:upper:]' '[:lower:]')
NEW_WIFI_MAC=$(echo ${NEW_WIFI_MAC} | sed 's/\(..\)/\1:/g;s/:$//')

if [[ ${boot_dev_found} == "true" ]]; then
if [[ -f /sysroot/boot/switchroot/joycon_mac.ini ]]; then
	# Collect joycon_00 info from ini
	JOYCON_00_TYPE=$(sed -nr "/^\[joycon_00\]/ { :l /^type[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}" /sysroot/boot/switchroot/joycon_mac.ini | tr -d "\\r\\n" )
	JOYCON_00_MAC=$(sed -nr "/^\[joycon_00\]/ { :l /^mac[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}" /sysroot/boot/switchroot/joycon_mac.ini | tr -d "\\r\\n")
	JOYCON_00_HOST_MAC=$(sed -nr "/^\[joycon_00\]/ { :l /^host[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}" /sysroot/boot/switchroot/joycon_mac.ini | tr -d "\\r\\n")
	JOYCON_00_LTK=$(sed -nr "/^\[joycon_00\]/ { :l /^ltk[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}" /sysroot/boot/switchroot/joycon_mac.ini | tr -d "\\r\\n")

	# collect joycon_00 info from ini
	JOYCON_01_TYPE=$(sed -nr "/^\[joycon_01\]/ { :l /^type[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}" /sysroot/boot/switchroot/joycon_mac.ini | tr -d "\\r\\n")
	JOYCON_01_MAC=$(sed -nr "/^\[joycon_01\]/ { :l /^mac[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}" /sysroot/boot/switchroot/joycon_mac.ini | tr -d "\\r\\n")
	JOYCON_01_HOST_MAC=$(sed -nr "/^\[joycon_01\]/ { :l /^host[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}" /sysroot/boot/switchroot/joycon_mac.ini | tr -d "\\r\\n")
	JOYCON_01_LTK=$(sed -nr "/^\[joycon_01\]/ { :l /^ltk[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}" /sysroot/boot/switchroot/joycon_mac.ini | tr -d "\\r\\n")
elif [[ -f /sysroot/boot/joycon_mac.ini ]]; then
	# Collect joycon_00 info from ini
	JOYCON_00_TYPE=$(sed -nr "/^\[joycon_00\]/ { :l /^type[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}" /sysroot/boot/joycon_mac.ini | tr -d "\\r\\n" )
	JOYCON_00_MAC=$(sed -nr "/^\[joycon_00\]/ { :l /^mac[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}" /sysroot/boot/joycon_mac.ini | tr -d "\\r\\n" )
	JOYCON_00_HOST_MAC=$(sed -nr "/^\[joycon_00\]/ { :l /^host[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}" /sysroot/boot/joycon_mac.ini | tr -d "\\r\\n" )
	JOYCON_00_LTK=$(sed -nr "/^\[joycon_00\]/ { :l /^ltk[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}" /sysroot/boot/joycon_mac.ini | tr -d "\\r\\n" )

	# Collect joycon_00 info from ini
	JOYCON_01_TYPE=$(sed -nr "/^\[joycon_01\]/ { :l /^type[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}" /sysroot/boot/joycon_mac.ini | tr -d "\\r\\n" )
	JOYCON_01_MAC=$(sed -nr "/^\[joycon_01\]/ { :l /^mac[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}" /sysroot/boot/joycon_mac.ini | tr -d "\\r\\n" )
	JOYCON_01_HOST_MAC=$(sed -nr "/^\[joycon_01\]/ { :l /^host[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}" /sysroot/boot/joycon_mac.ini | tr -d "\\r\\n" )
	JOYCON_01_LTK=$(sed -nr "/^\[joycon_01\]/ { :l /^ltk[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}" /sysroot/boot/joycon_mac.ini | tr -d "\\r\\n"  )
fi

if [[ -f /sysroot/boot/switchroot/joycon_mac.ini ]] || [[ -f /sysroot/boot/joycon_mac.ini ]]; then
	# Handle Host BT MAC. Agnostically.
	if [[ ! ${JOYCON_00_TYPE} == "0" ]]; then
		BT_MAC_ADDR=${JOYCON_00_HOST_MAC}
	elif [[ ! ${JOYCON_01_TYPE} == "0" ]]; then
		BT_MAC_ADDR=${JOYCON_01_HOST_MAC}
	fi
	# Handle Joycon Pair data.
	if [[ ${JOYCON_00_TYPE} == "1" ]]; then
		BT_DEV_00_NAME="Joy-Con (L)"
		BT_DEV_00_ID=8198
		BT_DEV_00_SERVICE_RECORDS="0x00000000=356E0900000A000000000900013503191000090004350D350619010009000135031900010900053503191002090006350909656E09006A090100090009350835061901000901000901002510576972656C6573732047616D65706164090101250747616D657061640902003503090100
0x00010000=36017D0900000A000100000900013503191124090004350D350619010009001135031900110900053503191002090006350909656E09006A0901000900093508350619112409010109000D350F350D350619010009001335031900110901002510576972656C6573732047616D65706164090101250747616D6570616409010225084E696E74656E646F090201090111090202080809020308210902042801090205280109020635B035AE082225AA05010905A1010601FF8521092175089530810285300930750895308102853109317508966901810285320932750896690181028533093375089669018102853F05091901291015002501750195108102050109391500250775049501814205097504950181010501093009310933093416000027FFFF00007510950481020601FF85010901750895309102851009107508953091028511091175089530910285120912750895309102C009020735083506090409090100090209280109020A280109020C090C8009020D280009020E2800
0x00010001=358C0900000A000100010900013503191200090004350D35061901000900013503190001090006350909656E09006A09010009000935083506191200090100090100251B576972656C6573732047616D6570616420506E5020536572766572090101250747616D6570616409020009010309020109057E0902020920060902030900010902042801090205090002"
	elif [[ ${JOYCON_00_TYPE} == "2" ]]; then
		BT_DEV_00_NAME="Joy-Con (R)"
		BT_DEV_00_ID=8199
		BT_DEV_00_SERVICE_RECORDS="0x00000000=356E0900000A000000000900013503191000090004350D350619010009000135031900010900053503191002090006350909656E09006A090100090009350835061901000901000901002510576972656C6573732047616D65706164090101250747616D657061640902003503090100
0x00010000=36017D0900000A000100000900013503191124090004350D350619010009001135031900110900053503191002090006350909656E09006A0901000900093508350619112409010109000D350F350D350619010009001335031900110901002510576972656C6573732047616D65706164090101250747616D6570616409010225084E696E74656E646F090201090111090202080809020308210902042801090205280109020635B035AE082225AA05010905A1010601FF8521092175089530810285300930750895308102853109317508966901810285320932750896690181028533093375089669018102853F05091901291015002501750195108102050109391500250775049501814205097504950181010501093009310933093416000027FFFF00007510950481020601FF85010901750895309102851009107508953091028511091175089530910285120912750895309102C009020735083506090409090100090209280109020A280109020C090C8009020D280009020E2800
0x00010001=358C0900000A000100010900013503191200090004350D35061901000900013503190001090006350909656E09006A09010009000935083506191200090100090100251B576972656C6573732047616D6570616420506E5020536572766572090101250747616D6570616409020009010309020109057E0902020920070902030900010902042801090205090002"
	fi

	if [[ ${JOYCON_01_TYPE} == "1" ]]; then
		BT_DEV_01_NAME="Joy-Con (L)"
		BT_DEV_01_ID=8198
		BT_DEV_01_SERVICE_RECORDS="0x00000000=356E0900000A000000000900013503191000090004350D350619010009000135031900010900053503191002090006350909656E09006A090100090009350835061901000901000901002510576972656C6573732047616D65706164090101250747616D657061640902003503090100
0x00010000=36017D0900000A000100000900013503191124090004350D350619010009001135031900110900053503191002090006350909656E09006A0901000900093508350619112409010109000D350F350D350619010009001335031900110901002510576972656C6573732047616D65706164090101250747616D6570616409010225084E696E74656E646F090201090111090202080809020308210902042801090205280109020635B035AE082225AA05010905A1010601FF8521092175089530810285300930750895308102853109317508966901810285320932750896690181028533093375089669018102853F05091901291015002501750195108102050109391500250775049501814205097504950181010501093009310933093416000027FFFF00007510950481020601FF85010901750895309102851009107508953091028511091175089530910285120912750895309102C009020735083506090409090100090209280109020A280109020C090C8009020D280009020E2800
0x00010001=358C0900000A000100010900013503191200090004350D35061901000900013503190001090006350909656E09006A09010009000935083506191200090100090100251B576972656C6573732047616D6570616420506E5020536572766572090101250747616D6570616409020009010309020109057E0902020920060902030900010902042801090205090002"
	elif [[ ${JOYCON_01_TYPE} == "2" ]]; then
		BT_DEV_01_NAME="Joy-Con (R)"
		BT_DEV_01_ID=8199
		BT_DEV_01_SERVICE_RECORDS="0x00000000=356E0900000A000000000900013503191000090004350D350619010009000135031900010900053503191002090006350909656E09006A090100090009350835061901000901000901002510576972656C6573732047616D65706164090101250747616D657061640902003503090100
0x00010000=36017D0900000A000100000900013503191124090004350D350619010009001135031900110900053503191002090006350909656E09006A0901000900093508350619112409010109000D350F350D350619010009001335031900110901002510576972656C6573732047616D65706164090101250747616D6570616409010225084E696E74656E646F090201090111090202080809020308210902042801090205280109020635B035AE082225AA05010905A1010601FF8521092175089530810285300930750895308102853109317508966901810285320932750896690181028533093375089669018102853F05091901291015002501750195108102050109391500250775049501814205097504950181010501093009310933093416000027FFFF00007510950481020601FF85010901750895309102851009107508953091028511091175089530910285120912750895309102C009020735083506090409090100090209280109020A280109020C090C8009020D280009020E2800
0x00010001=358C0900000A000100010900013503191200090004350D35061901000900013503190001090006350909656E09006A09010009000935083506191200090100090100251B576972656C6573732047616D6570616420506E5020536572766572090101250747616D6570616409020009010309020109057E0902020920070902030900010902042801090205090002"
	fi
	if [[ ! -d /sysroot/var/lib/bluetooth/${BT_MAC_ADDR}/cache ]]; then
		mkdir -p /sysroot/var/lib/bluetooth/${BT_MAC_ADDR}/cache
	fi

	if [[ ! ${JOYCON_00_TYPE} == "0" ]]; then
		if [[ ! -d /sysroot/var/lib/bluetooth/${BT_MAC_ADDR}/${JOYCON_00_MAC} ]]; then
			mkdir -p /sysroot/var/lib/bluetooth/${BT_MAC_ADDR}/${JOYCON_00_MAC}
			cat << EOF > /sysroot/var/lib/bluetooth/${BT_MAC_ADDR}/${JOYCON_00_MAC}/info
[General]
Name=${BT_DEV_00_NAME}
Class=0x000508
SupportedTechnologies=BR/EDR;
Trusted=true
Blocked=false
Services=00001000-0000-1000-8000-00805f9b34fb;00001124-0000-1000-8000-00805f9b34fb;00001200-0000-1000-8000-00805f9b34fb;
[LinkKey]
Key=${JOYCON_00_LTK}
Type=4
PINLength=0

[DeviceID]
Source=2
Vendor=1406
Product=${BT_DEV_00_ID}
Version=1

[ConnectionParameters]
MinInterval=5
MaxInterval=15
Latency=120
Timeout=600
EOF
		cat << EOF > /sysroot/var/lib/bluetooth/${BT_MAC_ADDR}/cache/${JOYCON_00_MAC}
[General]
Name=${BT_DEV_00_NAME}

[ServiceRecords]
${BT_DEV_00_SERVICE_RECORDS}
EOF
		fi
	fi

	if [[ ! ${JOYCON_01_TYPE} == "0" ]]; then
		if [[ ! -d /sysroot/var/lib/bluetooth/${BT_MAC_ADDR}/${JOYCON_01_MAC} ]]; then
			mkdir -p /sysroot/var/lib/bluetooth/${BT_MAC_ADDR}/${JOYCON_01_MAC}
			cat << EOF > /sysroot/var/lib/bluetooth/${BT_MAC_ADDR}/${JOYCON_01_MAC}/info
[General]
Name=${BT_DEV_01_NAME}
Class=0x000508
SupportedTechnologies=BR/EDR;
Trusted=true
Blocked=false
Services=00001000-0000-1000-8000-00805f9b34fb;00001124-0000-1000-8000-00805f9b34fb;00001200-0000-1000-8000-00805f9b34fb;
[LinkKey]
Key=${JOYCON_01_LTK}
Type=4
PINLength=0

[DeviceID]
Source=2
Vendor=1406
Product=${BT_DEV_01_ID}
Version=1

[ConnectionParameters]
MinInterval=5
MaxInterval=15
Latency=120
Timeout=600
EOF
		cat << EOF > /sysroot/var/lib/bluetooth/${BT_MAC_ADDR}/cache/${JOYCON_01_MAC}
[General]
Name=${BT_DEV_01_NAME}

[ServiceRecords]
${BT_DEV_01_SERVICE_RECORDS}
EOF

		fi
	fi
fi
fi

# Set btmac in firmware
if [[ ${BT_MAC_ADDR} == *":"* ]]; then
  BT_MAC_ADDR=$( echo ${BT_MAC_ADDR} | tr -d ':' )
fi
BT_MAC_ADDR=${BT_MAC_ADDR^^}

# Convert to little endian for firmware comparison and injection....
i=${#BT_MAC_ADDR}

while [ $i -gt 0 ]
do
	i=$((i-2))
	CONVERTED_MAC=${CONVERTED_MAC}$( echo -n "${BT_MAC_ADDR:$i:2}" )
done
NEW_BT_MAC=${CONVERTED_MAC};
CONVERTED_MAC=$( echo $CONVERTED_MAC | sed 's/../\\x&/g' )
if [[ -f /sysroot/lib/firmware/brcm/BCM4356A3.hcd ]]; then
   # Dump current mac to variable
   CURRENT_BT_MAC=$(/bin/xxd -p  -s 0x21 -l 6 -u /sysroot/lib/firmware/brcm/BCM4356A3.hcd)
   if [[ ! ${CURRENT_BT_MAC} == ${NEW_BT_MAC} ]]; then
	   # Write converted_mac to firmware file at 0x21 - 0x26
	   printf $CONVERTED_MAC | dd of=/sysroot/lib/firmware/brcm/BCM4356A3.hcd bs=1 seek=33 count=6 conv=notrunc
	   echo "BT address patched";
   fi
fi

#Patch wifi mac address
if [[ -f /sysroot/lib/firmware/brcm/brcmfmac4356-pcie.txt ]]; then
	CURRENT_WIFI_MAC=$(sed -nr "{ :l /^macaddr[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}" /sysroot/lib/firmware/brcm/brcmfmac4356-pcie.txt)
	if [[ ! ${CURRENT_WIFI_MAC} == ${NEW_WIFI_MAC} ]]; then
		#Patch WIFI Mac
		sed -i 's/macaddr=.*/macaddr='${NEW_WIFI_MAC}'/' /sysroot/lib/firmware/brcm/brcmfmac4356-pcie.txt
		echo "WIFI address patched";
	fi
fi

# Patch bluez config to enable fast connect, required or joycon wont connect
sed -i 's/#FastConnectable = false/FastConnectable = true/' /sysroot/etc/bluetooth/main.conf

umount /sysroot/boot

#Remount root file system as read only
mount -o remount,ro /sysroot
