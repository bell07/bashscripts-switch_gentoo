#!/bin/bash

#Downgrade USB3 to USB2
echo 0xffffffff > /sys/devices/70090000.xusb/downgrade_usb3

#Fix FBConsole/Virtual Terminals
echo 4 > /sys/class/graphics/fb0/blank;
echo 0 > /sys/class/graphics/fb0/state;
echo 0 > /sys/class/graphics/fb0/blank;

# Ready reboot 2 payload
echo 1 > /sys/devices/r2p/default_payload_ready;
